#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <ctype.h>

int s=0;
int main()
{
	int fd1[2],fd2[2];
	int c=0;

	if(pipe(fd1) == -1 || pipe(fd2)==-1)
	{
		fprintf(stderr, "piping failed\n");
		return -1;
	}
	c=fork();
	if(c==0)
	{
		while(1)
		{
			close(fd1[1]);
			close(fd2[0]);
			printf("inside child read\n");
		char buffer[100];
		read(fd1[0],buffer,100);
        
		printf("%s\n",buffer);

printf("inside child write\n");
		char data[100];
		fgets(data,100,stdin);
		 if(data[0] == EOF )break;
       // scanf("%ms",&data);
		write(fd2[1],data,strlen(data)+1);
		printf("\n ---------------------------------------\n\n\n");
		//close(fd1[0]);
		//close(fd2[1]);
	  }
	}
	else
	{
		while(1)
		{
			close(fd1[0]);
			close(fd2[1]);
			printf("inside parent write\n");
			char data[100];
		fgets(data,100,stdin);
		if(data[0] == EOF )exit(0);
         //scanf("%ms",&data);
		write(fd1[1],data,strlen(data)+1);
		printf("\n ---------------------------------------\n\n\n");
       
         printf("inside parent read\n");

		char buffer[100];
		read(fd2[0],buffer,100);
	
		printf("%s\n",buffer);

	   }
     }
 }