#include <arpa/inet.h>
#include <stdio.h>
#include <string.h>
#include<stdlib.h>
#include <sys/socket.h>
#include <sys/types.h>
#include<netinet/in.h>
#include <unistd.h>
#include<netdb.h>
#include<stdbool.h>
#include <errno.h>
#include <sys/time.h> 
#include<pthread.h>
#define size 3


pthread_t thread[3];

struct arg_struct {
    int arg;
};

void* server_execution(void *args){
    struct arg_struct *arg = (struct arg_struct *)args;
    int nnsfd = arg -> arg;
  // int nnsfd = nsfd;
     char buf[1000];
      char buf2[1000]="from server 3";
     while(1)
     {
        //bzero(buf,sizeof(buf));
                 memset(buf,'\0',sizeof(buf));
         recv(nnsfd,buf,sizeof(buf),0);

         printf("Client to server3 : %s\n",buf);

         //bzero(buf,sizeof(buf));
         printf("Server3 : %s\n",buf2);
         //fgets(buf2,sizeof(buf2),stdin);
         send(nnsfd,buf2,strlen(buf2)+1,0);
         if(strncmp("Bye",buf,3) == 0) 
		 {
			 close( nnsfd );  
		 }
     }
}


int main()
{
    int sfd,PORT=8002;
    dup2(3,sfd);
    	struct sockaddr_in addr;
     int addr_len = sizeof(addr);
     int i=0;
     int nsfd;
      while(1)
      {
          if( (nsfd= accept(sfd,(struct sockaddr*)&addr,(socklen_t*)&addr_len) )< 0)
          {
				perror("accept");
				exit(EXIT_FAILURE);
			}

                     struct arg_struct args;
                     args.arg=nsfd;
                    printf("Executing thread%d\n", i);
                    pthread_create(&thread[i++], NULL, (void*)server_execution, (void*)&args);
            
      }

}