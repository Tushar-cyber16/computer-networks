#include "./socket.hpp"
#define CLIENTS 3

int main() {
    int rsfd = server_raw_socket(15976);
    struct sockaddr_in cli_addr;
    cli_addr.sin_family = AF_INET;
    cli_addr.sin_addr.s_addr = INADDR_ANY;
    socklen_t cli_len = sizeof(cli_addr);
    printf("Sending from server\n");
    sendto(rsfd, "Announcement!", 14, 0, (struct sockaddr*)&cli_addr, cli_len);
    sleep(1);
}