#include<stdio.h>


int main()
{
    int x,y;
    scanf("%d",&x);
    scanf("%d",&y);
    FILE* fp =fopen("in.txt","w");
    
    //printf("%d %d\n",x,y);
    int z=y-x;
    fprintf(fp,"%d",z);
    printf("%d ",z);
    return 0;
}