#include <arpa/inet.h>
#include <errno.h>
#include <netinet/in.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <strings.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <semaphore.h>

#include <fcntl.h>
#include <sys/stat.h>
int main()
{
    sem_t *s1;
    printf("%d\n",getpid());


    s1 = sem_open("/my_semaphore1",O_CREAT,0666,0);

    sem_wait(s1);
    printf("signal received\n");
    sem_close(s1);
    sem_unlink("/my_semaphore1");
}