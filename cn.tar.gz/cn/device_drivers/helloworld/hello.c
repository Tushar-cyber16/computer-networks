#include <linux/module.h>
#include <linux/string.h>
#include <linux/kernel.h>
#include <linux/time.h>
#include <linux/fs.h>
// #include <linux/init.h>
MODULE_LICENSE("GPL");
MODULE_AUTHOR("DINESH REDDY");
MODULE_DESCRIPTION("Hello World Program");
MODULE_VERSION("0.1");
static int __init hello_start(void)
{
    printk(KERN_INFO "Loading Hello Module...\n");
    printk(KERN_INFO "Hello World...\n");
    return 0;
}
static void __exit hello_end(void)
{
    printk(KERN_INFO "Good Bye...\n");
}
module_init(hello_start);
module_exit(hello_end);