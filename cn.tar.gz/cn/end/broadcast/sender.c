#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <errno.h>
#include <unistd.h>

#define BROADCAST_ADDR "192.168.0.255" // the broadcast address for your network
#define PORT 12345 // the port number to use for sending and receiving messages
#define BUFFER_SIZE 1024 // the maximum size of the message buffer

int main() {
    // create a raw socket for sending messages
    int sockfd = socket(AF_INET, SOCK_RAW, IPPROTO_UDP);
    if (sockfd < 0) {
        perror("socket");
        exit(EXIT_FAILURE);
    }

    // enable broadcasting on the socket
    int broadcast_enable = 1;
    if (setsockopt(sockfd, SOL_SOCKET, SO_BROADCAST, &broadcast_enable, sizeof(broadcast_enable)) < 0) {
        perror("setsockopt");
        exit(EXIT_FAILURE);
    }

    // create a sockaddr_in structure for the broadcast address and port
    struct sockaddr_in broadcast_addr;
    memset(&broadcast_addr, 0, sizeof(broadcast_addr));
    broadcast_addr.sin_family = AF_INET;
    broadcast_addr.sin_addr.s_addr = INADDR_ANY;
    broadcast_addr.sin_port = htons(PORT);

    // send a message to the broadcast address
    char buffer[BUFFER_SIZE];
    memset(buffer, 0, sizeof(buffer));
    strcpy(buffer, "Hello, world!");
    int bytes_sent = sendto(sockfd, buffer, strlen(buffer), 0, (struct sockaddr*)&broadcast_addr, sizeof(broadcast_addr));
    if (bytes_sent < 0) {
        perror("sendto");
        exit(EXIT_FAILURE);
    }

    // close the socket
    close(sockfd);

    return 0;
}