#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <ctype.h>
#include <fcntl.h>
#include <sys/stat.h>

#define MAX_SIZE 100000

int main()
{
	char *myfifo = "/tmp/myfifo";
    
	mkfifo(myfifo,0666);
	
    int pfd = open("ser_pro.c",O_WRONLY);
    int fd = open(myfifo,O_RDONLY);

    char buffer[MAX_SIZE];

    read(fd,buffer,MAX_SIZE);
    write(pfd,buffer,strlen(buffer));
    printf("%s\n",buffer);

    system("gcc ser_pro.c -o ser_pro");

    int c=fork();

    if(c==0)
    {
        int itfd = open("it.txt",O_RDONLY);
        int poutfd = open("pout.txt",O_WRONLY);

        dup2(itfd,STDIN_FILENO);
        dup2(poutfd,STDOUT_FILENO);

        char *args[] =  {"./ser_pro",NULL};
        execvp(args[0],args);
        exit(0);
    }
    else
    {
      wait(NULL);






      fd = open(myfifo,O_WRONLY);
      char msg[100] = "test cases passed";
      write(fd,msg,strlen(msg)+1);
      close(fd);
      close(pfd);
    }

	return 0;
}