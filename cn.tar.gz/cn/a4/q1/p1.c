// C Program for Message Queue (Reader Process)
#include <stdio.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <unistd.h>
#include <stdlib.h>
#include <signal.h>
#define MAX 10


struct msg_buffer {
	long msg_type;
	char msg_text[100];
} message;

int p4pid;

void hd_fn1(int sig, siginfo_t *info, void *context){
	//printf("PID of signal sender = %d\n", info->si_pid);
	p4pid=info->si_pid;
}

int flag=0;
void p4_p1()
{
	printf("SIGNAL FROM P4 TO P1\n");
	flag=1;
}
void p2_p1()
{
	printf("SIGNAL FROM P2 TO P1\n");
	flag=1;
}
int main()
{
	key_t key;
	int msgid;
    int left ,right;

	key = ftok("progfile", 65);

	msgid = msgget(key, 0666 | IPC_CREAT);

	msgrcv(msgid, &message, sizeof(message), 2, 0);

     int p2pid = atoi(message.msg_text);
     printf("Data Received from p2 to p1 is  : %d \n",p2pid);
     right = p2pid;
	msgctl(msgid, IPC_RMID, NULL);
    
    printf("signal send from p1 to p2 %d\n",getpid());
    kill(p2pid,SIGUSR1);


	while(1) {
	   //signal(SIGUSR1,hdfn);
	   struct sigaction ss;
	ss.sa_flags = SA_SIGINFO;
	ss.sa_sigaction= hd_fn1;
	sigaction(SIGUSR1, &ss, NULL);
	pause();
	   
	   if(p4pid!=0)break;
	   } 
	printf("signal received from p4 to p1 is %d\n",p4pid);
    left = p4pid;

    printf("CIRCULAR SIGNALLING\n");
    for(int i=0;i<3;i++)
	{
		kill(right,SIGUSR1);
		while(1)
		{
            signal(SIGUSR1,p4_p1);
			if(flag){flag=0;break;}
		}
	}
    printf("\n\n\n");
	printf("REVERSE CIRCULAR SIGNALLING\n");
    for(int i=0;i<4;i++)
	{
		kill(left,SIGUSR1);
		while(1)
		{
            signal(SIGUSR1,p2_p1);
			if(flag){flag=0;break;}
		}
	}


	return 0;
}
