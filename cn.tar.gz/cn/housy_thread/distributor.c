#include<time.h>
#include<stdio.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<string.h>
#include<sys/select.h>
#include<pthread.h>
#include<signal.h>
#include<stdlib.h>
#include<fcntl.h>
#include<sys/shm.h>
#include<unistd.h>
#include<sys/un.h>
#include<netinet/ip.h>
#include<arpa/inet.h>
#include <stddef.h>
#include<errno.h>
#include<netinet/if_ether.h>
#include<net/ethernet.h>
#include<netinet/ether.h>
#include<netinet/udp.h>

#define PORT 8000

char* path1 = "mysocket";
char* path2 = "mysocket2";
int send_fd(int socket, int fd_to_send)
 {
  struct msghdr socket_message;
  struct iovec io_vector[1];
  struct cmsghdr *control_message = NULL;
  char message_buffer[1];
  /* storage space needed for an ancillary element with a paylod of length is CMSG_SPACE(sizeof(length)) */
  char ancillary_element_buffer[CMSG_SPACE(sizeof(int))];
  int available_ancillary_element_buffer_space;

  /* at least one vector of one byte must be sent */
  message_buffer[0] = 'F';
  io_vector[0].iov_base = message_buffer;
  io_vector[0].iov_len = 1;

  /* initialize socket message */
  memset(&socket_message, 0, sizeof(struct msghdr));
  socket_message.msg_iov = io_vector;
  socket_message.msg_iovlen = 1;

  /* provide space for the ancillary data */
  available_ancillary_element_buffer_space = CMSG_SPACE(sizeof(int));
  memset(ancillary_element_buffer, 0, available_ancillary_element_buffer_space);
  socket_message.msg_control = ancillary_element_buffer;
  socket_message.msg_controllen = available_ancillary_element_buffer_space;

  /* initialize a single ancillary data element for fd passing */
  control_message = CMSG_FIRSTHDR(&socket_message);
  control_message->cmsg_level = SOL_SOCKET;
  control_message->cmsg_type = SCM_RIGHTS;
  control_message->cmsg_len = CMSG_LEN(sizeof(int));
  *((int *) CMSG_DATA(control_message)) = fd_to_send;

  return sendmsg(socket, &socket_message, 0);
 }


int inet_serv_listen(int port)
{
    struct sockaddr_in servaddr;
    int sfd, len;
    int opt=1;
    if((sfd = socket(AF_INET, SOCK_STREAM, 0))==0) 
    {
        perror("socket");
        exit(1);
    }
    if(setsockopt(sfd, SOL_SOCKET, SO_REUSEADDR | SO_REUSEPORT,&opt, sizeof(int))) 
    { 
        perror("setsockopt"); 
        exit(1); 
    } 
    servaddr.sin_family=AF_INET;
    servaddr.sin_addr.s_addr = htonl(INADDR_ANY); 
    servaddr.sin_port = htons(port);
    if(bind(sfd, (struct sockaddr*)&servaddr,sizeof(servaddr))<0)
    {
        perror("bind");
        exit(1);
    } 

    if(listen(sfd,10)<0)
    {
        perror("listen");
        exit(1);
    }
    return sfd;
}

int serv_listen(char* path) 
{
    int fd, len;
    struct sockaddr_un u;

    if((fd = socket(AF_UNIX, SOCK_STREAM, 0))<0) 
    {
        perror("socket");
        exit(1);
    }

    unlink(path);
    u.sun_family = AF_UNIX;
    strcpy(u.sun_path, path);
    len = offsetof(struct sockaddr_un, sun_path) + strlen(path);
    if(bind(fd, (struct sockaddr*)&u, len)<0) 
    {
        perror("bind");
        exit(1);
    }

    if(listen(fd,10)<0) 
    {
        perror("listen");
        exit(1);
    }

    return fd;
}

int main()
{

    struct sockaddr_in inet_cliaddr1,inet_cliaddr2,inet_cliaddr3 ;
    int clen1,clen2,clen3;
    int nsfd[3];
    int sfd = inet_serv_listen(PORT);

    clen1=sizeof(inet_cliaddr1);
    if((nsfd[0]=accept(sfd,(struct sockaddr*)&inet_cliaddr1,&clen1))<0)
    {
        perror("inet 1 accept");
        exit(1);
    }
    else printf("connected to client\n");

    clen2=sizeof(inet_cliaddr2);
    if((nsfd[1]=accept(sfd,(struct sockaddr*)&inet_cliaddr2,&clen2))<0)
    {
        perror("inet 1 accept");
        exit(1);
    }
    else printf("connected to client\n");

    clen3=sizeof(inet_cliaddr3);
    if((nsfd[2]=accept(sfd,(struct sockaddr*)&inet_cliaddr3,&clen3))<0)
    {
        perror("inet 1 accept");
        exit(1);
    }
    else printf("connected to client\n");


    char buf1[1000]="32 12 52 30 ";
    send(nsfd[0],buf1,strlen(buf1)+1,0);

    char buf2[1000]="13 42 34 65 ";
    send(nsfd[1],buf2,strlen(buf2)+1,0);

    char buf3[1000]="19 12 70 84 ";
    send(nsfd[2],buf3,strlen(buf3)+1,0);

     
      
    char buf4[1000]="12 13 14 15 ";
    send(nsfd[0],buf4,strlen(buf4)+1,0);

    char buf5[1000]="16 17 18 19 ";
    send(nsfd[1],buf5,strlen(buf5)+1,0);

    char buf6[1000]="20 21 22 23 ";
    send(nsfd[2],buf6,strlen(buf6)+1,0);
    









      struct sockaddr_un s1_addr;
      int len;
      int usfd,nusfd,nsfdd;

      len = sizeof(s1_addr);

      usfd=serv_listen(path1);

    if((nusfd = accept(usfd, (struct sockaddr*)&s1_addr, &len)) < 0) 
    {
        perror("accept s1");
        exit(1);
    }
    else printf("connected to service server\n");

    if(send_fd(nusfd,nsfd[0]) < 0){
        perror("send_fd failed\n");
        exit(0);
    }
    else printf("fd sent %d\n",nsfd[0]);

    if(send_fd(nusfd,nsfd[1]) < 0){
        perror("send_fd failed\n");
        exit(0);
    }
    else printf("fd sent %d\n",nsfd[1]);

    if(send_fd(nusfd,nsfd[2]) < 0){
        perror("send_fd failed\n");
        exit(0);
    }
    else printf("fd sent %d\n",nsfd[2]);
   
   char buf[1000];

     recv(nusfd,buf,sizeof(buf),0);

     int win = atoi(buf);

     int final,i;
     if(win == nsfd[0]){i=1;final=nsfd[0];}
     else if(win == nsfd[1]) {i=2;final = nsfd[1];}
     else {i=3;final = nsfd[2];}
     printf("winner is client %d with fd %d\n",i,final);
     

   // int uusfd = serv_listen(path2);
    int prize;
    
    if((prize= accept(usfd, (struct sockaddr*)&s1_addr, &len)) < 0) 
    {
        perror("accept s1");
        exit(1);
    }
    else printf("connected to service server\n");

    if(send_fd(prize,nsfd[i-1]) < 0){
        perror("send_fd failed\n");
        exit(0);
    }
    else printf("fd sent %d\n",nsfd[i-1]);

    //while(1){continue;}
    
}