#include<stdio.h>

int main(){
	printf("Sending data from P6\n");
    return 0;
}