#include<time.h>
#include<stdio.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<string.h>
#include<sys/select.h>
#include<pthread.h>
#include<signal.h>
#include<stdlib.h>
#include<fcntl.h>
#include<sys/shm.h>
#include<unistd.h>
#include<sys/un.h>
#include<netinet/ip.h>
#include<arpa/inet.h>
#include<errno.h>
#include<netinet/if_ether.h>
#include<net/ethernet.h>
#include<netinet/ether.h>
#include<netinet/udp.h>
#include<sys/ipc.h>
#include<sys/msg.h>
#include <semaphore.h>
#include<sys/wait.h>
#define socketPath "mysocket"
    int nusfd[3] , nsfd[3],flag[3];
    sem_t *s1,*s2,*s3;

struct arg_struct {
    int nsfd,usfd,i;
};


int send_fd(int socket, int fd_to_send)
 {
  struct msghdr socket_message;
  struct iovec io_vector[1];
  struct cmsghdr *control_message = NULL;
  char message_buffer[1];
  /* storage space needed for an ancillary element with a paylod of length is CMSG_SPACE(sizeof(length)) */
  char ancillary_element_buffer[CMSG_SPACE(sizeof(int))];
  int available_ancillary_element_buffer_space;

  /* at least one vector of one byte must be sent */
  message_buffer[0] = 'F';
  io_vector[0].iov_base = message_buffer;
  io_vector[0].iov_len = 1;

  /* initialize socket message */
  memset(&socket_message, 0, sizeof(struct msghdr));
  socket_message.msg_iov = io_vector;
  socket_message.msg_iovlen = 1;

  /* provide space for the ancillary data */
  available_ancillary_element_buffer_space = CMSG_SPACE(sizeof(int));
  memset(ancillary_element_buffer, 0, available_ancillary_element_buffer_space);
  socket_message.msg_control = ancillary_element_buffer;
  socket_message.msg_controllen = available_ancillary_element_buffer_space;

  /* initialize a single ancillary data element for fd passing */
  control_message = CMSG_FIRSTHDR(&socket_message);
  control_message->cmsg_level = SOL_SOCKET;
  control_message->cmsg_type = SCM_RIGHTS;
  control_message->cmsg_len = CMSG_LEN(sizeof(int));
  *((int *) CMSG_DATA(control_message)) = fd_to_send;

  return sendmsg(socket, &socket_message, 0);
 }

void* u_connect(void *args)
{
   int usfd = socket(AF_UNIX,SOCK_STREAM,0);
    struct sockaddr_un addr;
    addr.sun_family = AF_UNIX;
    strcpy(addr.sun_path,socketPath);

    unlink(socketPath);
    if(bind(usfd,(struct sockaddr*)&addr,sizeof(addr)) < 0){
        perror("bind fail ");
        exit(0);
    }
    if(listen(usfd,5) < 0){
        perror("listen fail ");
        exit(0);
    }

    struct sockaddr_un clien;
    socklen_t clienlen = sizeof(clien);
    for(int i=0;i<3;i++)
    {
    nusfd[i] = accept(usfd,(struct sockaddr*)&clien,&clienlen);
    printf("connected to p%d\n",i+1);
    }
    //exit(1);
}

int soc_connect()
{
     int PORT = 8000;
    struct sockaddr_in serv_addr;
    int addr_len = sizeof(serv_addr);
    int sfd ;
    if( (sfd = socket(AF_INET,SOCK_STREAM,0) ) < 0)
    {
        fprintf(stderr,"socket connection failed");
        exit(EXIT_FAILURE);
    }
    
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(PORT);
    serv_addr.sin_addr.s_addr =INADDR_ANY;
    //bcopy((char*) server->h_addr , (char*) serv_addr.sin_addr.s_addr , server->h_length);

    if( bind(sfd,(struct sockaddr*) &serv_addr,sizeof(serv_addr)) < 0)
    {
        fprintf(stderr,"bind error");
       exit(EXIT_FAILURE);
    }
    
    if(listen(sfd,3) < 0)
    {
        fprintf(stderr, "listen failed");
        exit(EXIT_FAILURE);
    }

   // for(int i=0;i<3;i++)
   // {
   // nsfd[i] = accept(sfd,(struct sockaddr*) &serv_addr,(socklen_t*) &addr_len)  ;
   // printf("connected to t%d\n",i+1);
    //}
    //exit(1);
    return sfd;
}

void* sendfd(void *args)
{
    struct arg_struct *arg = (struct arg_struct *)args;
    int nsfd = arg -> nsfd;
    int usfd = arg->usfd;
    int i = arg->i;

    if(send_fd(usfd,nsfd) < 0){
        perror("send_fd failed\n");
        exit(0);
    }
    else printf("fd send\n");

    if(i==0)sem_wait(s1);
    else if(i==1) sem_wait(s2);
    else sem_wait(s3);

    flag[i]=0;
    //exit(1);
}
    

int main()
{
      
     s1 = sem_open("/my_semaphore1", O_CREAT, 0666, 0);
     s2 = sem_open("/my_semaphore2", O_CREAT, 0666, 0);
     s3 = sem_open("/my_semaphore3", O_CREAT, 0666, 0);
     pthread_t thread,thread1;
     pthread_create(&thread, NULL, (void*)u_connect, (void*)0);
     //pthread_create(&thread1, NULL, (void*)soc_connect, (void*)0);
     pthread_join(thread,NULL);
     //pthread_join(thread1,NULL);
     //u_connect();
     int sfd = soc_connect();
     sleep(5);
     flag[0]=0;flag[1]=0;flag[2]=0;

     fd_set rfds;
     FD_ZERO(&rfds);
     //int x=nsfd[0];
     //for(int i=0;i<3;i++) 
     //{
      //   if(x>nsfd[i])x=nsfd[i];
     //    FD_SET(nsfd[i],&rfds);
     //}
     FD_SET(sfd,&rfds);
     int cnt=0;
     while(1)
     {
         int retval = select(sfd+1,&rfds,NULL,NULL,NULL);
         if (retval == -1) 
         {
            perror("select");
            exit(EXIT_FAILURE);
        } 
        else if (retval == 0) 
        {
            // Timeout occurred
            printf("Timeout occurred\n");
        } 
        else 
        {
            struct sockaddr_in clie_addr;
              int clie_len = sizeof(clie_addr);
            int nsfd = accept(sfd,(struct sockaddr*) &clie_addr,(socklen_t*) &clie_len)  ;
                  char data[1000] = "connected to train";
                 // for(int i=0;i<3;i++) send(nusfd[i],data,strlen(data)+1,0);

                  for(int i=0;i<3;i++)
                  {
                      if(flag[i]==1) continue;

                      flag[i]=1;
                      struct arg_struct args;
                     args.nsfd=nsfd;
                     args.i = i;
                     args.usfd = nusfd[i];
                     pthread_t thread2;
                    pthread_create(&thread2, NULL, (void*)sendfd, (void*)&args);
                    break;
                  }
            
        }
    }
     
    
     return 0;
}