#include<time.h>
#include<stdio.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<string.h>
#include<sys/select.h>
#include<pthread.h>
#include<signal.h>
#include<stdlib.h>
#include<fcntl.h>
#include<sys/shm.h>
#include<unistd.h>
#include<sys/un.h>
#include<netinet/ip.h>
#include<arpa/inet.h>

#include<errno.h>
#include<netinet/if_ether.h>
#include<net/ethernet.h>
#include<netinet/ether.h>
#include<netinet/udp.h>
#include <string.h> 
#include <sys/types.h> 
#include <unistd.h> 
#include <stddef.h>
#include <sys/stat.h>

#define PORT 8000


int cli_connect(int port)
{
    int sfd;
	  
    struct sockaddr_in servaddr; 

    int n, len; 
    // Creating socket file descriptor 
    if ((sfd = socket(AF_INET, SOCK_STREAM, 0)) < 0) 
    { 
        printf("socket creation failed"); 
        exit(0); 
    } 
  
    memset(&servaddr, 0, sizeof(servaddr)); 
  
    // Filling server information 
    servaddr.sin_family = AF_INET; 
    servaddr.sin_port = htons(port); 
    servaddr.sin_addr.s_addr = inet_addr("127.0.0.1");

    if (connect(sfd, (struct sockaddr*)&servaddr, sizeof(servaddr)) < 0) 
    { 
        printf("\n Error : Connect Failed \n"); 
    }  
    return sfd;
}
int main()
{

    int sfd;
    sfd = cli_connect(PORT);
   
    
    char buffer[1024];
    while(1)
    {
        memset(buffer, 0, sizeof(buffer)); 
        printf("client : ");
        fgets(buffer,sizeof(buffer),stdin);
        //strcpy(buffer, "Hello Server"); 
       send(sfd, buffer, sizeof(buffer),0); 
        printf("Message from server: "); 
        recv(sfd, buffer, sizeof(buffer),0);
        printf("%s\n",buffer); 
        sleep(2);
        //puts(buffer);
    }
    close(sfd); 
}