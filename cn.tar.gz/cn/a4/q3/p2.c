#include <stdio.h>
#include <semaphore.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/stat.h>

int main()
{
    sem_t *s12,*s23;
    s12 = sem_open("/my_semaphore1", O_CREAT, 0666, 0);
    s23 = sem_open("/my_semaphore2", O_CREAT, 0666, 0);

    while(1)
    {
    printf(" I am P2. I am waiting for Semaphore S12\n");
    sem_wait(s12);
    printf("I got semaphore S12 signalling from P1\n");

    printf("Enter any character to sem-signal( S23)\n");
    char ch;
    scanf("%c",&ch);
    printf("I am signalling semaphore signal of S23\n");
    sem_post(s23);

    }

    sem_close(s12);
    sem_close(s23);
    sem_unlink("/my_semaphore1");
    sem_unlink("/my_semaphore2");
    return 0;
}