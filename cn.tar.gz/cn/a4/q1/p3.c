
#include <stdio.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <unistd.h>
#include <stdlib.h>
#include <signal.h>
#define MAX 10

struct mesg_buffer {
	long msg_type;
	char msg_text[100];
} message;

int p2pid=0;

void hd_fn(int sig, siginfo_t *info, void *context){
	//printf("PID of signal sender = %d\n", info->si_pid);
	p2pid=info->si_pid;
}

int flag=0;
void p2_p3()
{
	printf("SIGNAL FROM P2 TO P3\n");
	flag=1;
}

void p4_p3()
{
	printf("SIGNAL FROM P4 TO P3\n");
	flag=1;
}
int main()
{
	key_t key;
	int msgid;
    int left,right;

	key = ftok("progfile", 65);


	msgid = msgget(key, 0666 | IPC_CREAT);
	message.msg_type = 3;

     pid_t pid;
    pid = getpid();
    sprintf(message.msg_text,"%d\n",pid);

	msgsnd(msgid, &message, sizeof(message), 0);

	printf("Data send from p3 is : %s \n", message.msg_text);

   while(1) {
	   //signal(SIGUSR1,hdfn);
	   struct sigaction si;
	si.sa_flags = SA_SIGINFO;
	si.sa_sigaction= hd_fn;
	sigaction(SIGUSR1, &si, NULL);
	pause();
	   
	   if(p2pid!=0)break;
	   }
	printf("signal received from p2 to p3 is %d\n",p2pid);
   left = p2pid;
	

	key = ftok("progfile", 65);

	msgid = msgget(key, 0666 | IPC_CREAT);

	msgrcv(msgid, &message, sizeof(message), 4, 0);

     int p4pid = atoi(message.msg_text);
     printf("Data Received from p4 to p3 is  : %d \n",p4pid);
     right = p4pid;
	//msgctl(msgid, IPC_RMID, NULL);
    
	printf("signal send from p3 to p4 %d\n",getpid());
    kill(p4pid,SIGUSR1);


    for(int i=0;i<3;i++)
	{
		
		while(1)
		{
            signal(SIGUSR1,p2_p3);
			if(flag){flag=0;break;}
		}
		kill(right,SIGUSR1);
	}
   
   for(int i=0;i<3;i++)
	{
		
		while(1)
		{
            signal(SIGUSR1,p4_p3);
			if(flag){flag=0;break;}
		}
		kill(left,SIGUSR1);
	}
	return 0;
}
