#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <ctype.h>
#include <fcntl.h>
#include <sys/stat.h>

int main(int argc ,char* argv[])
{

    char name[]={"./p1"};
    char buffer[100];

    fgets(buffer,100,stdin);

    //write(fd[1],buffer,strlen(buffer)+1);

    //dup2(STDOUT_FILENO,3);
    int i;
    //dup2(STDIN_FILENO,3);
    //dup2(STDOUT_FILENO,4);
    for(i=1;i<argc-1;i++)
    {
        int c=0;
        int fd1[2],fd[2];
         if(pipe(fd1) == -1 || pipe(fd)==-1)
    {
        fprintf(stderr,"piping failed");
        return -1;
    }
        c=fork();
        if(c>0)
        {
            wait(NULL);
            //char data[100];
            //read(fd[0],data,100);
            //printf("%s\n",data);
            //dup2(3,STDIN_FILENO);
            //dup2(4,STDOUT_FILENO);
           memset(buffer, 0, sizeof(buffer));
            read(fd1[0],buffer,sizeof(buffer));
            //printf("%s\n",buffer);
            //close(fd1);
            //close(fd);
        }
        else
        {
            printf("process %d\n",i);
            write(fd[1],buffer,strlen(buffer)+1);
            
            dup2(fd[0],STDIN_FILENO);
            dup2(fd1[1],STDOUT_FILENO);
            //char* args[] ={argv[i],NULL};
            //execvp(args[0],args);
            name[3]=i+'0';
            char* args[] ={name,NULL};
            execvp(args[0],args);
            exit(0);
        }
    }
     //dup2(3,STDOUT_FILENO);
        printf("process %d\n",i);
          int fd[2];
         if(pipe(fd)==-1)
    {
        fprintf(stderr,"piping failed");
        return -1;
    }
    write(fd[1],buffer,strlen(buffer)+1);
        int c=0;
        c=fork();
        if(c>0)
        {
            wait(NULL);
            //dup2(3,STDIN_FILENO);
            //char data[100];
            //read(fd[0],data,100);
            //printf("%s\n",data);
        }
        else
        {
            dup2(fd[0],STDIN_FILENO);
            name[3]='4';
            char* args[] ={name,NULL};
            execvp(args[0],args);
        }
}
