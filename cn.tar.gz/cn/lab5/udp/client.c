#include <stdio.h>
#include <string.h> //strlen
#include <stdlib.h>
#include <errno.h>
#include <unistd.h> //close
#include <arpa/inet.h> //close
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/time.h>

int main()
{
    struct sockaddr_in serv_addr;

    int sfd;

    if( (sfd= socket(AF_INET,SOCK_DGRAM,0)) < 0)
    {
        perror("socket failed");
        exit(EXIT_FAILURE);
    }

    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(8000);
    serv_addr.sin_addr.s_addr = INADDR_ANY;

    
     int addr_len = sizeof(serv_addr);
     char buf[400] ;
     fgets(buf,sizeof(buf),stdin);
     sendto(sfd,buf,sizeof(buf) , 0,(struct sockaddr*) &serv_addr,sizeof(serv_addr));

     
     memset(buf,'\0',sizeof(buf));
     recvfrom(sfd,buf,sizeof(buf),0,(struct sockaddr*) &serv_addr,(socklen_t*)&addr_len);
     printf("Server : %s\n",buf);
     close(sfd);
     return 0;
}