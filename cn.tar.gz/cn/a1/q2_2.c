#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <ctype.h>

int main()
{
    int fd[2];
    if(pipe(fd) == -1)
	{
		fprintf(stderr, "piping failed\n");
		return -1;
	}


    dup2(STDIN_FILENO,fd[0]);
    dup2(STDOUT_FILENO,fd[1]);

    dup2(3,STDIN_FILENO);
    dup2(4,STDOUT_FILENO);

    while(1)
    {
    char buffer[100];
    read(fd[0],buffer,100);
    printf("I am process 2 \n");
    printf("%s\n",buffer);

    char data[100];
    fgets(data,100,stdin);

    write(fd[1],data,strlen(data)+1);
    }
}