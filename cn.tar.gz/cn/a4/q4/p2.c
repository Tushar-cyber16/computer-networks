#include <stdio.h>
#include <semaphore.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <stdlib.h>
#include <string.h>
#include <sys/shm.h>
#include <sys/types.h>
#include <errno.h>

#define SHM_KEY1 0x1234
#define SHM_KEY2 0x1235

int main()
{
    sem_t *s1,*s2;
    s1 = sem_open("/my_semaphore1",O_CREAT,0666,0);
    s2 = sem_open("/my_semaphore2",O_CREAT,0666,0);

    
    key_t keyx = ftok("shmfile1",65);
    key_t keyy = ftok("shmfile2",66);

  
    int shmidx = shmget(SHM_KEY1,1024,0666|IPC_CREAT);
    int shmidy = shmget(SHM_KEY2,1024,0666|IPC_CREAT);

    int *strx = (int*) shmat(shmidx,(void*)0,0);
    int *stry = (int*) shmat(shmidy,(void*)0,0);

    while(1)
    {
        printf(" I am waiting for S1\n");
        sem_wait(s1);
        

        printf(" I am reading shm x\n");
        
        *stry = *strx+1;
        printf("shm x : %d  , new value of shm y : %d\n",*strx,*stry);

        char ch;
        printf(" Enter any char to signal S2\n");
        scanf("%c",&ch);
        sem_post(s2);
    }

    sem_close(s1);
    sem_unlink("/my_semaphore1");
    sem_close(s2);
    sem_unlink("/my_semaphore2");

    shmdt(strx);
    shmdt(stry);
    shmctl(shmidx,IPC_RMID,NULL);
}