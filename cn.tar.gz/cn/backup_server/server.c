
#include<time.h>
#include<stdio.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<string.h>
#include<sys/select.h>
#include<pthread.h>
#include<signal.h>
#include<stdlib.h>
#include<fcntl.h>
#include<sys/shm.h>
#include<unistd.h>
#include<sys/un.h>
#include<netinet/ip.h>
#include<arpa/inet.h>
#include <stddef.h>
#include<errno.h>
#include <semaphore.h>
#include<netinet/if_ether.h>
#include<net/ethernet.h>
#include<netinet/ether.h>
#include<netinet/udp.h>

#define PORT 8000
#define SHM_KEY1 0x1234
int flag=0;
struct client {
    int nsfd;
};
struct backup{
    int client[30];
};
int client[30];
int inet_serv_listen(int port)
{
    struct sockaddr_in servaddr;
    int sfd, len;
    int opt=1;
    if((sfd = socket(AF_INET, SOCK_STREAM, 0))==0) 
    {
        perror("socket");
        exit(1);
    }
    if(setsockopt(sfd, SOL_SOCKET, SO_REUSEADDR | SO_REUSEPORT,&opt, sizeof(int))) 
    { 
        perror("setsockopt"); 
        exit(1); 
    } 
    servaddr.sin_family=AF_INET;
    servaddr.sin_addr.s_addr = htonl(INADDR_ANY); 
    servaddr.sin_port = htons(port);
    if(bind(sfd, (struct sockaddr*)&servaddr,sizeof(servaddr))<0)
    {
        perror("bind");
        exit(1);
    } 

    if(listen(sfd,10)<0)
    {
        perror("listen");
        exit(1);
    }
    return sfd;
}

void* handle_client(void *args)
{
    struct client *arg = (struct client*) args;
    int nsfd = arg->nsfd;

    char buf[1000];
    while(1)
    {
        printf("from client : ");

        recv(nsfd,buf,sizeof(buf),0);
        printf("%s\n",buf);
        if(strncmp("Bye",buf,3) == 0 ) break;
         if(flag==1) break;


        printf("server : ");

        fgets(buf,sizeof(buf),stdin);
        send(nsfd,buf,sizeof(buf),0);

    }
}
int main()
{
    int sfd = inet_serv_listen(PORT);
    client[0]=sfd;
    struct sockaddr_in inet_cliaddr ;
    int clen;
    if((client[1]=accept(sfd,(struct sockaddr*)&inet_cliaddr,&clen))<0)
    {
        perror("inet 1 accept");
        exit(1);
    }
    else printf("client connected\n");

    char buf[1000];
    while(1)
    {
        
        //sleep(4);
        recv(client[1],buf,sizeof(buf),0);
        printf("from client : %s\n",buf);
        if(strncmp("Bye",buf,3) == 0 ) break;

       bzero(buf,sizeof(buf));
        printf("server : ");

        fgets(buf,sizeof(buf),stdin);
        send(client[1],buf,sizeof(buf),0);
        sleep(2);

    }
    /*if((client[2]=accept(sfd,(struct sockaddr*)&inet_cliaddr,&clen))<0)
    {
        perror("inet 1 accept");
        exit(1);
    }

     pthread_t thread1 , thread2;
     struct client cli;
     cli.nsfd = client[1];
     pthread_create(&thread1, NULL, (void*)handle_client, (void*)&cli);
     struct client cli2;
     cli2.nsfd = client[2];
     pthread_create(&thread2, NULL, (void*)handle_client, (void*)&cli2);
    
*/
    int shmid = shmget(SHM_KEY1,1024,0666|IPC_CREAT);

     struct backup *c= (struct backup*) shmat(shmid,(void*)0,0);

     //for(int i=0;i<30;i++) c->client[i] = client[i];
     c->client[0] = sfd;
    c->client[1] = client[1];
    printf("client0 %d, client1 %d\n",client[0],client[1]);

     //sleep(30);
     //flag=1;
     printf("enter a char to transfer this server : ");
     char ch;
     scanf("%c",&ch);
     sem_t* s;
     s= sem_open("/my_semaphore3", O_CREAT, 0666, 0);
      //pthread_join(thread1,NULL);
      // pthread_join(thread2,NULL);
     sem_post(s);
     

}