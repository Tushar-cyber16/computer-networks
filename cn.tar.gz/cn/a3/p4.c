#include<stdio.h>


int main()
{
    int x,y;
    scanf("%d",&x);
    //printf("%d\n",x);
    FILE* fp =fopen("in4.txt","w");
      fprintf(fp,"%d",x);
    y=x/2;

    printf("%d ",y);
    return 0;
}