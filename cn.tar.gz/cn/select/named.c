#include <stdio.h>
#include <sys/time.h>
#include <sys/types.h>
#include <unistd.h>
#include<string.h>

#include <sys/wait.h>
#include <ctype.h>
#include <fcntl.h>
#include <sys/stat.h>
int main()
{
    char *myfifo = "/tmp/myfifo";

    mkfifo(myfifo,0666);

    int nfd = open(myfifo,O_WRONLY);

    
        char buf[100] = "message from named.c to server";
        write(nfd,buf,strlen(buf)+1);
    close(nfd);
    return 0;
}