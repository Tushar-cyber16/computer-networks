#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/select.h>
#include <sys/types.h>
#include <sys/time.h>

#define BUFFER_SIZE 256

int main() {
    int pipefd[2];
    pid_t pid;
    char buffer[BUFFER_SIZE];

    // Create a pipe for interprocess communication
    if (pipe(pipefd) == -1) {
        perror("pipe");
        exit(EXIT_FAILURE);
    }

    // Fork the process
    pid = fork();
    if (pid == -1) {
        perror("fork");
        exit(EXIT_FAILURE);
    }

    // Child process
    if (pid == 0) {
        // Close the write end of the pipe
        close(pipefd[0]);

        // Read data from standard input and send it to the parent process
        while (fgets(buffer, BUFFER_SIZE, stdin) != NULL) {
            write(pipefd[1], buffer, BUFFER_SIZE);
        }

        // Close the read end of the pipe
        close(pipefd[1]);

        exit(EXIT_SUCCESS);
    }

    // Parent process
    // Close the read end of the pipe
    close(pipefd[1]);

    // Use select to wait for input from the child process
    fd_set readfds;
    struct timeval timeout;
    int retval;
    while (1) {
        // Set up the fd_set for select
        FD_ZERO(&readfds);
        FD_SET(pipefd[0], &readfds);

        // Set up the timeout for select
        timeout.tv_sec = 1;
        timeout.tv_usec = 0;

        // Wait for input from the child process
        retval = select(pipefd[0] + 1, &readfds, NULL, NULL, &timeout);
        if (retval == -1) {
            perror("select");
            exit(EXIT_FAILURE);
        } else if (retval == 0) {
            // Timeout occurred
            printf("Timeout occurred\n");
        } else {
            // Input is ready to be read from the pipe
            read(pipefd[0], buffer, BUFFER_SIZE);
            printf("%s", buffer);
        }
    }

    // Close the write end of the pipe
    close(pipefd[0]);
 return 0;
}