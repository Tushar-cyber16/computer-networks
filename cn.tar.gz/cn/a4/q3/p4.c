#include <stdio.h>
#include <semaphore.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/stat.h>

int main()
{
    sem_t *s34,*s41;
    s34 = sem_open("/my_semaphore3", O_CREAT, 0666, 0);
    s41 = sem_open("/my_semaphore4", O_CREAT, 0666, 0);

    while(1)
    {
    printf(" I am P4. I am waiting for Semaphore S34\n");
    sem_wait(s34);
    printf("I got semaphore S34 signalling from P3\n");

    printf("Enter any character to sem-signal( S41)\n");
    char ch;
    scanf("%c",&ch);
    printf("I am signalling semaphore signal of S41\n");
    sem_post(s41);

    }

    sem_close(s34);
    sem_close(s41);
    sem_unlink("/my_semaphore3");
    sem_unlink("/my_semaphore4");
    return 0;
}