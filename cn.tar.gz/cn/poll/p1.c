#include<stdio.h>

int main(){
  
	printf("Sending data from P1\n");
    return 0;
}