#include <arpa/inet.h>
#include <stdio.h>
#include <string.h>
#include<stdlib.h>
#include <sys/socket.h>
#include <sys/types.h>
#include<netinet/in.h>
#include <unistd.h>
#include<netdb.h>

int main(int argc,char* argv[])
{
     
    int PORT = 8000;
    struct sockaddr_in serv_addr;
    struct hostent *server;

    //server = gethostbyname(argv[1]);

    //if(server == NULL)
    //{
     //   fprintf(stderr,"invalid server name");
     //   exit(EXIT_FAILURE);
    //}

    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(PORT);
    serv_addr.sin_addr.s_addr = inet_addr("127.0.0.1");
   // bcopy( (char*) server->h_addr , (char*) &serv_addr.sin_addr.s_addr,server->h_length);

    int sfd;
    if( ( sfd = socket(AF_INET,SOCK_STREAM,0) ) < 0)
    {
         fprintf(stderr,"socket connection failed");
        exit(EXIT_FAILURE);
    }

    if(connect(sfd,(struct sockaddr*) &serv_addr,sizeof(serv_addr)) < 0)
    {
        fprintf(stderr,"connection failed");
        exit(EXIT_FAILURE);
    }
      
      char buf[300];
       while(1)
      {
          fgets(buf,sizeof(buf),stdin);
          send(sfd,buf,strlen(buf)+1,0);
          if(strncmp("Leaving",buf,3) == 0) 
		 { 
            break;
		 }

      }
 
}
