#include<bits/stdc++.h>
#include "./socket.hpp"

int main() {
    int rsfd = client_raw_socket(15976);
    struct sockaddr_in addr;
    socklen_t cli_len = sizeof(addr);
    char buf[1024];
    recvfrom(rsfd, buf, 1024, 0, (struct sockaddr*)&addr, &cli_len);
    struct iphdr* ip = (struct iphdr*)buf;
    printf("%s\n", (buf + (ip->ihl) * 4));
}