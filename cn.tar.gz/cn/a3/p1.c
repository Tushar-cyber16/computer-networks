#include<stdio.h>


int main()
{
    int x,y;
    scanf("%d",&x);
    scanf("%d",&y);
    int z=x+y;

    printf("%d %d \n",z,z+5);
    return 0;
}