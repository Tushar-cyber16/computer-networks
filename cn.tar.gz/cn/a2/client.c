#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <ctype.h>
#include <fcntl.h>
#include <sys/stat.h>

#define MAX_SIZE 100000


int main()
{
    char *myfifo = "/tmp/myfifo";
    
	mkfifo(myfifo,0666);
	
    int fd = open(myfifo,O_WRONLY);
    int pfd=open("program.c",O_RDONLY);
     
     char buffer[MAX_SIZE];
    read(pfd,buffer,MAX_SIZE);
    write(fd,buffer,strlen(buffer)+1);

    close(pfd);
    close(fd);

    fd= open(myfifo,O_RDONLY);

    read(fd,buffer,MAX_SIZE);

    printf("%s\n",buffer);
    close(fd);

    return 0;

}