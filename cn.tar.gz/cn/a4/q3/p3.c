#include <stdio.h>
#include <semaphore.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/stat.h>

int main()
{
    sem_t *s34,*s23;
    s34 = sem_open("/my_semaphore3", O_CREAT, 0666, 0);
    s23 = sem_open("/my_semaphore2", O_CREAT, 0666, 0);

    while(1)
    {
    printf(" I am P3. I am waiting for Semaphore S23\n");
    sem_wait(s23);
    printf("I got semaphore S23 signalling from P2\n");

    printf("Enter any character to sem-signal( S34)\n");
    char ch;
    scanf("%c",&ch);
    printf("I am signalling semaphore signal of S34\n");
    sem_post(s34);

    }

    sem_close(s34);
    sem_close(s23);
    sem_unlink("/my_semaphore3");
    sem_unlink("/my_semaphore2");
    return 0;
}