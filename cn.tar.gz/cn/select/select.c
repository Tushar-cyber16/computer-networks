#include <stdio.h>
#include <sys/time.h>
#include <sys/types.h>
#include <unistd.h>
#include<string.h>
#include <sys/wait.h>
#include <ctype.h>
#include <fcntl.h>
#include <sys/stat.h>
int main(void) {
    
    char *myfifo = "/tmp/myfifo";
    char buf[500];
    mkfifo(myfifo,0666);

    int nfd = open(myfifo,O_RDONLY);

    int ffd[2];
    if(pipe(ffd) == -1){fprintf(stderr,"error");return 0;}

    int c=0;
    c=fork();
    if(c==0)
    {
        dup2(ffd[1],STDOUT_FILENO);
        char *args[] ={"./test",NULL};
        execvp(args[0],args);
    }
    else
    {
      wait(NULL);
    }
    fd_set rfds;
    struct timeval tv;
    int retval;
    tv.tv_sec = 2;
    tv.tv_usec=0;
    int i=0;
    while(i<5)
    {i++;
        FD_ZERO(&rfds);
        FD_SET(nfd,&rfds);
        FD_SET(ffd[0],&rfds);


        retval = select(ffd[0]+1,&rfds,NULL,NULL,&tv);

        if(retval == -1){printf("error\n");}
        else if(retval==0){printf("timeout occurred\n");}
        else
        {
           if(FD_ISSET(nfd,&rfds))
           {
               printf("reading from named pipe\n");
               read(nfd,buf,sizeof(buf));
               printf("%s\n\n",buf);
           }
           if(FD_ISSET(ffd[0],&rfds))
           {
               printf("reading from pipe\n");
               read(ffd[0],buf,sizeof(buf));
               printf("%s\n\n",buf);
           }
        }
      memset(buf, '\0', sizeof(buf));
    }
    close(nfd);
    close(ffd[0]);
    close(ffd[1]);

}
