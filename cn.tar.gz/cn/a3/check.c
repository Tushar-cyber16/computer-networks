#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <ctype.h>
#include <fcntl.h>
#include <sys/stat.h>

#include <poll.h>

int main(int argc ,char* argv[])
{


    char buffer[100];
    fgets(buffer,100,stdin);
    
    FILE* p1 = popen("./p1","w");
    fputs(buffer,p1);
    //pclose(p1);
    //p1=popen("./p1","r");
    //fgets(buffer,sizeof(buffer),p1);
    //printf("%s 3",buffer);
      pclose(p1);
}
