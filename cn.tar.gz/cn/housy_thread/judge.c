#include<time.h>
#include<stdio.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<string.h>
#include<sys/select.h>
#include<pthread.h>
#include<signal.h>
#include<stdlib.h>
#include<fcntl.h>
#include<sys/shm.h>
#include<unistd.h>
#include<sys/un.h>
#include<netinet/ip.h>
#include<arpa/inet.h>
#include<errno.h>
#include<netinet/if_ether.h>
#include<net/ethernet.h>
#include<netinet/ether.h>
#include<netinet/udp.h>
#include<sys/ipc.h>
#include<sys/msg.h>
#define socketPath "mysocket"

int win=-1;
int flag=0;
int recvfd[3];
int usfd;
int recv_fd(int socket)
 {
  int sent_fd, available_ancillary_element_buffer_space;
  struct msghdr socket_message;
  struct iovec io_vector[1];
  struct cmsghdr *control_message = NULL;
  char message_buffer[1];
  char ancillary_element_buffer[CMSG_SPACE(sizeof(int))];

  /* start clean */
  memset(&socket_message, 0, sizeof(struct msghdr));
  memset(ancillary_element_buffer, 0, CMSG_SPACE(sizeof(int)));

  /* setup a place to fill in message contents */
  io_vector[0].iov_base = message_buffer;
  io_vector[0].iov_len = 1;
  socket_message.msg_iov = io_vector;
  socket_message.msg_iovlen = 1;

  /* provide space for the ancillary data */
  socket_message.msg_control = ancillary_element_buffer;
  socket_message.msg_controllen = CMSG_SPACE(sizeof(int));

  if(recvmsg(socket, &socket_message, MSG_CMSG_CLOEXEC) < 0)
   return -1;

  if(message_buffer[0] != 'F')
  {
   /* this did not originate from the above function */
   return -1;
  }

  if((socket_message.msg_flags & MSG_CTRUNC) == MSG_CTRUNC)
  {
   /* we did not provide enough space for the ancillary element array */
   return -1;
  }

  /* iterate ancillary elements */
   for(control_message = CMSG_FIRSTHDR(&socket_message);
       control_message != NULL;
       control_message = CMSG_NXTHDR(&socket_message, control_message))
  {
   if( (control_message->cmsg_level == SOL_SOCKET) &&
       (control_message->cmsg_type == SCM_RIGHTS) )
   {
    sent_fd = *((int *) CMSG_DATA(control_message));
    return sent_fd;
   }
  }

  return -1;
 }
// void winner(int sig, siginfo_t *info, void *context){
void winner(int sig, siginfo_t *info, void *context){
	//printf("PID of signal sender = %d\n", info->si_pid);
    flag=1;
	win=info->si_pid;
    //win = 4;
    char b[100] = "Bye";
    char id[100];
    for(int i=0;i<3;i++)
    {
        
        if(win == recvfd[i]) 
        {
            printf("client %d is winner with fd %d\n",i+1,win); 
            sprintf(id,"%d",win);
            send(usfd,id,strlen(id)+1,0);
        }
        else
        {
            send(recvfd[i],b,strlen(b)+1,0);
        }
    }

}
void won()
{
    while(1)
    {
    struct sigaction s;
	s.sa_flags = SA_SIGINFO;
	s.sa_sigaction= winner;
	sigaction(SIGUSR2, &s, NULL);
    if(win!=-1)break;
    }
}


int main()
{
       printf("%d\n",getpid());
        usfd = socket(AF_UNIX,SOCK_STREAM,0);

    struct sockaddr_un addr;
    addr.sun_family = AF_UNIX;
    strcpy(addr.sun_path,socketPath);

 
    if(connect(usfd,(struct sockaddr *)&addr,sizeof(addr))==-1)
	perror("\n connect ");
   
    
    if((recvfd[0] = recv_fd(usfd)) == -1){
        perror("recv fd failed");
        exit(0);
    }
   else printf("fd received %d\n",recvfd[0]);

   if((recvfd[1] = recv_fd(usfd)) == -1){
        perror("recv fd failed");
        exit(0);
    }
   else printf("fd received %d\n",recvfd[1]);

   if((recvfd[2] = recv_fd(usfd)) == -1){
        perror("recv fd failed");
        exit(0);
    }
   else printf("fd received %d\n",recvfd[2]);
  
    /* struct sigaction s;
	s.sa_flags = SA_SIGINFO;
	s.sa_sigaction= winner;
	sigaction(SIGUSR1, &s, NULL);*/
    //signal(SIGUSR1,won);
    
   char buf[1000];
  while(1)
  {
     int x= rand()%101;
     sprintf(buf,"%d",x);
     send(recvfd[0],buf,strlen(buf)+1,0);
     send(recvfd[1],buf,strlen(buf)+1,0);
     send(recvfd[2],buf,strlen(buf)+1,0);

     char buf1[100],buf2[100],buf3[100],id[100];
     recv(recvfd[0],buf1,sizeof(buf1),0);
     if(buf1[0]!='p') {printf("client1 won\n");send(recvfd[1],"Bye",4,0);send(recvfd[2],"Bye",4,0); sprintf(id,"%d",recvfd[0]);send(usfd,id,strlen(id)+1,0);break;}

     recv(recvfd[1],buf2,sizeof(buf2),0);
     if(buf2[0]!='p') {printf("client2 won\n");send(recvfd[0],"Bye",4,0);send(recvfd[2],"Bye",4,0);sprintf(id,"%d",recvfd[1]);send(usfd,id,strlen(id)+1,0);break;}

     recv(recvfd[2],buf3,sizeof(buf3),0);
     if(buf3[0]!='p') {printf("client3 won\n");send(recvfd[0],"Bye",4,0);send(recvfd[1],"Bye",4,0);sprintf(id,"%d",recvfd[2]);send(usfd,id,strlen(id)+1,0);break;}
     if(flag==1) break;
     sleep(3);
  }

    //while(1){continue;}
    return 0;


}