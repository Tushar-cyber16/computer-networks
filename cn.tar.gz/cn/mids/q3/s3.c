#include <arpa/inet.h>
#include <stdio.h>
#include <string.h>
#include<stdlib.h>
#include <sys/socket.h>
#include <sys/types.h>
#include<netinet/in.h>
#include <unistd.h>
#include<netdb.h>

int main(int argc , char* argv[])
{
    

    int PORT = 8003;
    struct sockaddr_in serv_addr;
    int addr_len = sizeof(serv_addr);
    int sfd ;
    if( (sfd = socket(AF_INET,SOCK_STREAM,0) ) < 0)
    {
        fprintf(stderr,"socket connection failed");
        exit(EXIT_FAILURE);
    }
    
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(PORT);
    serv_addr.sin_addr.s_addr =INADDR_ANY;
    //bcopy((char*) server->h_addr , (char*) serv_addr.sin_addr.s_addr , server->h_length);

    if( bind(sfd,(struct sockaddr*) &serv_addr,sizeof(serv_addr)) < 0)
    {
        fprintf(stderr,"bind error");
       exit(EXIT_FAILURE);
    }
    
    if(listen(sfd,3) < 0)
    {
        fprintf(stderr, "listen failed");
        exit(EXIT_FAILURE);
    }
   
   while(1)
   {
    int nsfd;
    if( (nsfd = accept(sfd,(struct sockaddr*) &serv_addr,(socklen_t*) &addr_len) ) < 0 )
    {
        fprintf(stderr, "connection failed");
        exit(EXIT_FAILURE);
    }
     
     char buf[300];
    while(1)
    {
         bzero(buf,sizeof(buf));
         recv(nsfd,buf,sizeof(buf),0);

         printf("Client3 : %s\n",buf);
         
         bzero(buf,sizeof(buf));
         printf("Server3 : ");
         fgets(buf,sizeof(buf),stdin);
         send(nsfd,buf,strlen(buf)+1,0);
         if(strncmp("Bye",buf,3) == 0) break;
        
    }
    close(nsfd);
   }
    
    close(sfd);
    shutdown(sfd,SHUT_RDWR);
}
