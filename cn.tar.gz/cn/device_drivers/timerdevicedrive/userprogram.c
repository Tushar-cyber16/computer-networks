#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<fcntl.h>
#include<sys/wait.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<string.h>
int main()
{
    int fd=open("/dev/timer_dd",O_RDWR);
    if(fd<0)
    {
        printf("Failed to open device driver\n");
        return 0;
    }
    printf("Timer Device Driver Opened Successfully\n");
    int t;
    do
    {
        printf("\nSet Timer in second (enter -1 to break) : ");
        scanf("%d",&t);
        if(t==-1) break;
        char s[1000];
        sprintf(s,"%d",t);
        write(fd,s,strlen(s));
        printf("\nTimer Set for %d seconds!\n",t);
        char s1[1000];
        int r=read(fd,s1,1000);
        s1[r]='\0';
        printf("\n%s\n",s1);
    }while(t!=-1);
    return 0;
}
