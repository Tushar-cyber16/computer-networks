#include <arpa/inet.h>
#include <errno.h>
#include <netinet/in.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <strings.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <semaphore.h>

#include <fcntl.h>
#include <sys/stat.h>
int main()
{
   
    sem_t *s1;
    s1 = sem_open("/my_semaphore1",O_CREAT,0666,0);
   
     const char* process_name = "hello"; // Replace with the name of the process you want to get the PID of
    char command[256];

    // Construct the command to run pidof
    snprintf(command, sizeof(command), "pidof %s", process_name);

    // Open a pipe to the pidof command
    FILE* fp = popen(command, "r");

    if (fp == NULL) {
        printf("Failed to run command\n");
        return 1;
    }

    // Read the PID from the pidof output
    int pid;
    fscanf(fp, "%d", &pid);

    // Close the pipe
    pclose(fp);

    // Print the PID to the console
    printf("PID of process %s: %d\n", process_name, pid);




    sem_post(s1);
    sem_close(s1);
    sem_unlink("/my_semaphore1");
}
