#include<stdio.h>

int main(){
	printf("Sending data from P3\n");
  return 0;
}