
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netinet/ip.h>
#include <errno.h>
#include <unistd.h>

#define BROADCAST_ADDR "192.168.0.255" // the broadcast address for your network
#define PORT 12345 // the port number to use for sending and receiving messages
#define BUFFER_SIZE 1024 // the maximum size of the message buffer

int main() {
    // create a raw socket for receiving messages
    int sockfd = socket(AF_INET, SOCK_RAW, IPPROTO_UDP);
    if (sockfd < 0) {
        perror("socket");
        exit(EXIT_FAILURE);
    }

    // enable broadcasting on the socket
    int broadcast_enable = 1;
    if (setsockopt(sockfd, SOL_SOCKET, SO_BROADCAST, &broadcast_enable, sizeof(broadcast_enable)) < 0) {
        perror("setsockopt");
        exit(EXIT_FAILURE);
    }

    // bind the socket to the broadcast address and port
    struct sockaddr_in recv_addr;
    memset(&recv_addr, 0, sizeof(recv_addr));
    recv_addr.sin_family = AF_INET;
    recv_addr.sin_addr.s_addr = INADDR_ANY;
    recv_addr.sin_port = htons(PORT);
    if (bind(sockfd, (struct sockaddr*)&recv_addr, sizeof(recv_addr)) < 0) {
        perror("bind");
        exit(EXIT_FAILURE);
    }

    // receive incoming messages and print them to the console
    char buffer[BUFFER_SIZE];
    struct sockaddr_in sender_addr;
    socklen_t sender_addr_len = sizeof(sender_addr);
    int bytes_received;
    while (1) {
        bytes_received = recvfrom(sockfd, buffer, sizeof(buffer), 0, (struct sockaddr*)&sender_addr, &sender_addr_len);
        if (bytes_received < 0) {
            perror("recvfrom");
            exit(EXIT_FAILURE);
        }
        buffer[bytes_received] = '\0';
        struct iphdr *ip;
		ip = (struct iphdr*)buffer;
        printf("Received message from %s:%d: %s\n", inet_ntoa(sender_addr.sin_addr), ntohs(sender_addr.sin_port),buffer+(ip->ihl*4));
    }

    // close the socket
    close(sockfd);

    return 0;
}