#include <stdio.h>
#include <semaphore.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/stat.h>

int main()
{
    sem_t *s12,*s41;
    s12 = sem_open("/my_semaphore1", O_CREAT, 0666, 0);
    s41 = sem_open("/my_semaphore4", O_CREAT, 0666, 0);

    while(1)
    {
    printf(" I am P1. Enter any character to sem-signal( S12)\n");
    char ch;
    scanf("%c",&ch);
    printf("I am signalling semaphore signal of S12\n");
    sem_post(s12);
    
    printf("I am waiting for semaphore S41\n");
    sem_wait(s41);
    printf(" I got semaphore signalling from P4 \n\n");

    }

    sem_close(s12);
    sem_close(s41);
    sem_unlink("/my_semaphore1");
    sem_unlink("/my_semaphore4");
    return 0;
}