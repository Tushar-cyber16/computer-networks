#include <arpa/inet.h>
#include <stdio.h>
#include <string.h>
#include<stdlib.h>
#include <sys/socket.h>
#include <sys/types.h>
#include<netinet/in.h>
#include <unistd.h>
#include<netdb.h>
#include<stdbool.h>
#include <errno.h>
#include <sys/time.h> 
#include<stdbool.h>
#include <errno.h>
#include <sys/time.h> 
#include<pthread.h>
int flag[5];
int ssfd[5];
struct arg_struct {
    int arg;
};
void connect_to_servers()
{
    int PORT = 8001;
    struct sockaddr_in serv_addr[5];

    for(int i=0;i<5;i++)
    {
    serv_addr[i].sin_family = AF_INET;
    serv_addr[i].sin_port = htons(PORT+i);
    serv_addr[i].sin_addr.s_addr = inet_addr("127.0.0.1");
   // bcopy( (char*) server->h_addr , (char*) &serv_addr.sin_addr.s_addr,server->h_length);

    if( ( ssfd[i] = socket(AF_INET,SOCK_STREAM,0) ) < 0)
    {
         fprintf(stderr,"socket connection failed");
        exit(EXIT_FAILURE);
    }

    if(connect(ssfd[i],(struct sockaddr*) &serv_addr[i],sizeof(serv_addr[i])) < 0)
    {
        fprintf(stderr,"connection failed");
        exit(EXIT_FAILURE);
    }
    }
}

void* server1(void *args){
    struct arg_struct *arg = (struct arg_struct *)args;
    int nnsfd = arg -> arg;
     char buf[1000],buf2[1000];
     while(1)
     {
        recv(nnsfd,buf,sizeof(buf),0);
        send(ssfd[0],buf,sizeof(buf),0);

        recv(ssfd[0],buf,sizeof(buf),0);
        send(nnsfd,buf,sizeof(buf),0);
        if(strncmp("Bye",buf,3) == 0) break;
     }
     flag[0]=0;
     close(nnsfd);
     exit(0);
}
void* server2(void *args){
    struct arg_struct *arg = (struct arg_struct *)args;
    int nnsfd = arg -> arg;
     char buf[1000],buf2[1000];
     while(1)
     {
        recv(nnsfd,buf,sizeof(buf),0);
        send(ssfd[1],buf,sizeof(buf),0);

        recv(ssfd[1],buf,sizeof(buf),0);
        send(nnsfd,buf,sizeof(buf),0);
        if(strncmp("Bye",buf,3) == 0) break;
     }
     flag[1]=0;
     close(nnsfd);
     exit(0);
}
void* server3(void *args){
    struct arg_struct *arg = (struct arg_struct *)args;
    int nnsfd = arg -> arg;
     char buf[1000],buf2[1000];
     while(1)
     {
        recv(nnsfd,buf,sizeof(buf),0);
        send(ssfd[2],buf,sizeof(buf),0);

        recv(ssfd[2],buf,sizeof(buf),0);
        send(nnsfd,buf,sizeof(buf),0);
        if(strncmp("Bye",buf,3) == 0) break;
     }
     flag[2]=0;
     close(nnsfd);
     exit(0);
}
void* server4(void *args){
    struct arg_struct *arg = (struct arg_struct *)args;
    int nnsfd = arg -> arg;
     char buf[1000],buf2[1000];
     while(1)
     {
        recv(nnsfd,buf,sizeof(buf),0);
        send(ssfd[3],buf,sizeof(buf),0);

        recv(ssfd[3],buf,sizeof(buf),0);
        send(nnsfd,buf,sizeof(buf),0);
        if(strncmp("Bye",buf,3) == 0) break;
     }
     flag[3]=0;
     close(nnsfd);
     exit(0);
}
void* server5(void *args){
    struct arg_struct *arg = (struct arg_struct *)args;
    int nnsfd = arg -> arg;
     char buf[1000],buf2[1000];
     while(1)
     {
        recv(nnsfd,buf,sizeof(buf),0);
        send(ssfd[4],buf,sizeof(buf),0);

        recv(ssfd[4],buf,sizeof(buf),0);
        send(nnsfd,buf,sizeof(buf),0);
       if(strncmp("Bye",buf,3) == 0) break;
     }
     flag[4]=0;
     close(nnsfd);
     exit(0);
}
int main()
{
    connect_to_servers();
    for(int i=0;i<5;i++) flag[i]=0;
    fd_set rfds;
    struct sockaddr_in addr;
    int addr_len = sizeof(addr);

    int sfd;

     if( ( ( sfd = socket(AF_INET,SOCK_STREAM,0) ) )< 0)
    {
        fprintf(stderr,"socket connection failed");
        exit(EXIT_FAILURE);
    }
    int opt = true;
    if(setsockopt(sfd,SOL_SOCKET,SO_REUSEADDR | SO_REUSEPORT , (char*)&opt,sizeof(opt)) < 0 )
    {
		perror("setsockopt");
		exit(EXIT_FAILURE);
	}

    addr.sin_family = AF_INET;
    addr.sin_port = htons(8000);
    addr.sin_addr.s_addr =INADDR_ANY;

    if( bind(sfd,(struct sockaddr*) &addr,sizeof(addr)) < 0)
    {
        fprintf(stderr,"bind error");
       exit(EXIT_FAILURE);
    }
    
    if(listen(sfd,5) < 0)
    {
        fprintf(stderr, "listen failed");
        exit(EXIT_FAILURE);
    }
    

    int nsfd;
    FD_ZERO(&rfds);
    FD_SET(sfd,&rfds);
    while(1)
    {
        int retval = select(sfd+1,&rfds,NULL,NULL,NULL);
        if ((retval < 0) && (errno!=EINTR))
		{
			printf("select error");
		}

        if(FD_ISSET(sfd,&rfds))
        {
            if( (nsfd= accept(sfd,(struct sockaddr*)&addr,(socklen_t*)&addr_len) )< 0)
            {
				perror("accept");
				exit(EXIT_FAILURE);
			}

            char buff[100];
            recv(nsfd,buff,sizeof(buff),0);
            if(strncmp(buff,"S1",2) == 0)
            {
                if(flag[0]==1) {
                    printf("Connection failed : s1 already handling a client\n");
                    send(nsfd,"failed",7,0);
                }
                else
                {
                    flag[0] =1;
                    pthread_t thread;
                    struct arg_struct args;
                     args.arg=nsfd;
                    printf("Executing thread\n");
                    pthread_create(&thread, NULL, (void*)server1, (void*)&args);
                }
            }
            else if(strncmp(buff,"S2",2) == 0)
            {
                if(flag[1]==1) {
                    printf("Connection failed : s2 already handling a client\n");
                    send(nsfd,"failed",7,0);
                }
                else
                {
                    flag[1] =1;
                    pthread_t thread;
                    struct arg_struct args;
                     args.arg=nsfd;
                    printf("Executing thread\n");
                    pthread_create(&thread, NULL, (void*)server2, (void*)&args);
                }
            }
            else if(strncmp(buff,"S3",2) == 0)
            {
                if(flag[2]==1) {
                    printf("Connection failed : s3 already handling a client\n");
                    send(nsfd,"failed",7,0);
                }
                else
                {
                    flag[2] =1;
                    pthread_t thread;
                    struct arg_struct args;
                     args.arg=nsfd;
                    printf("Executing thread\n");
                    pthread_create(&thread, NULL, (void*)server3, (void*)&args);
                }
            }
            else if(strncmp(buff,"S4",2) == 0)
            {
                if(flag[3]==1) {
                    printf("Connection failed : s4 already handling a client\n");
                    send(nsfd,"failed",7,0);
                }
                else
                {
                    flag[3] =1;
                    pthread_t thread;
                    struct arg_struct args;
                     args.arg=nsfd;
                    printf("Executing thread\n");
                    pthread_create(&thread, NULL, (void*)server4, (void*)&args);
                }
            }
            else if(strncmp(buff,"S5",2) == 0)
            {
                if(flag[4]==1) {
                    printf("Connection failed : s5 already handling a client\n");
                    send(nsfd,"failed",7,0);
                }
                else
                {
                    flag[4] =1;
                    pthread_t thread;
                    struct arg_struct args;
                     args.arg=nsfd;
                    printf("Executing thread\n");
                    pthread_create(&thread, NULL, (void*)server5, (void*)&args);
                }
            }

        }
    }
}