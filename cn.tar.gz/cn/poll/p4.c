#include<stdio.h>

int main(){
	printf("Sending data from P4\n");
  return 0;
}