#include<time.h>
#include<stdio.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<string.h>
#include<sys/select.h>
#include<pthread.h>
#include<signal.h>
#include<stdlib.h>
#include<fcntl.h>
#include<sys/shm.h>
#include<unistd.h>
#include<sys/un.h>
#include<netinet/ip.h>
#include<arpa/inet.h>

#include<errno.h>
#include<netinet/if_ether.h>
#include<net/ethernet.h>
#include<netinet/ether.h>
#include<netinet/udp.h>
#include <string.h> 
#include <sys/types.h> 
#include <unistd.h> 
#include <stddef.h>
#include <sys/stat.h>

#define PORT 8000
int coupon[4],couponn[4];
int sfd;
int X,winner=0,flag=0,glo,pi=0;

int cli_connect(int port)
{
    int sfd;
	  
    struct sockaddr_in servaddr; 

    int n, len; 
    // Creating socket file descriptor 
    if ((sfd = socket(AF_INET, SOCK_STREAM, 0)) < 0) 
    { 
        printf("socket creation failed"); 
        exit(0); 
    } 
  
    memset(&servaddr, 0, sizeof(servaddr)); 
  
    // Filling server information 
    servaddr.sin_family = AF_INET; 
    servaddr.sin_port = htons(port); 
    servaddr.sin_addr.s_addr = inet_addr("127.0.0.1");

    if (connect(sfd, (struct sockaddr*)&servaddr, sizeof(servaddr)) < 0) 
    { 
        printf("\n Error : Connect Failed \n"); 
    }  
    return sfd;
}

void convertcoupontoarray(char buf[])
{
    int x=0,cnt=0;
    
    for(int i=0;i<1000;i++)
    {
        int j=i;
        for( ;j<1000;j++)
        {
            if(buf[j]==' ' ) break;
            
            x*=10;
            x+=(buf[j]-'0');
        }
        i=j;
        coupon[cnt++]=x;
        x=0;
        if(cnt==4) break;
    }
}

/*void convertcoupontoarrayy(char buf[])
{
    int x=0,cnt=0;
    
    for(int i=0;i<1000;i++)
    {
        int j=i;
        for( ;j<1000;j++)
        {
            if(buf[j]==' ' ) break;
            
            x*=10;
            x+=(buf[j]-'0');
        }
        i=j;
        couponn[cnt++]=x;
        x=0;
        if(cnt==4) break;
    }
}
*/

void* cou_com(void* args)
{
    char buff[100];
    while(1)
    {
        recv(sfd,buff,sizeof(buff),0);
        if( strncmp("Bye",buff,3) == 0 ) break;
        int x = atoi(buff);
        printf("%d\n",x);
        glo=x;pi=1;
        int cnt=0;
        for(int i=0;i<4;i++)
        {
           if(coupon[i]==-1)cnt++;
           if(coupon[i] == x)coupon[i]=-1;
        }
        if(cnt==4)
        {
            send(sfd,"b",1,0);
            flag=1;
            winner=1;
           // kill(X,SIGUSR1);
            sleep(2);
           // kill(X,SIGUSR2);
            break;
        }
        send(sfd,"p",1,0);
        sleep(2);
    }
}

/*void* cou_comm(void* args)
{
    char buff[100];
    while(1)
    {
        //recv(sfd,buff,sizeof(buff),0);
        //if( strncmp("Bye",buff,3) == 0 ) break;
       // int x = atoi(buff);
       // printf("%d\n",x);
       while(pi==0){}
       pi=0;
       int x=glo;
        int cnt=0;
        for(int i=0;i<4;i++)
        {
           if(couponn[i]==-1)cnt++;
           if(couponn[i] == x)couponn[i]=-1;
        }
        if(cnt==4)
        {
            //send(sfd,"b",1,0);
            flag=1;
            winner=1;
           // kill(X,SIGUSR1);
            sleep(2);
           // kill(X,SIGUSR2);
            break;
        }
        
        sleep(2);
    }
}*/
int main()
{
     

    
    sfd = cli_connect(PORT);
   
    
    /*char buffer[1024];
    while(1)
    {
        memset(buffer, 0, sizeof(buffer)); 
        printf("client : ");
        fgets(buffer,sizeof(buffer),stdin);
        //strcpy(buffer, "Hello Server"); 
       send(sfd, buffer, sizeof(buffer),0); 
        printf("Message from server: "); 
        recv(sfd, buffer, sizeof(buffer),0);
        printf("%s\n",buffer); 
        //puts(buffer);
    }
    close(sfd); */

    char buf[1000];
    recv(sfd,buf,sizeof(buf),0);
    printf("coupon received : %s\n",buf);
    convertcoupontoarray(buf);
    for(int i=0;i<4;i++)printf("%d ",coupon[i]);
    printf("\n");


   /* char buf1[1000];
    recv(sfd,buf1,sizeof(buf1),0);
    printf("coupon received : %s\n",buf1);
    convertcoupontoarrayy(buf1);
    for(int i=0;i<4;i++)printf("%d ",couponn[i]);
    printf("\n");*/
     
     sleep(5);
    int fd = fileno(popen("pidof ./judge", "r"));	
     char pi[1000];
	read(fd, &pi, 1000);
	 X = atoi(pi);
    printf("%d\n",X);
    

    pthread_t thread,thread1;
    pthread_create(&thread, NULL, (void*)cou_com, (void*)0);
   // pthread_create(&thread1, NULL, (void*)cou_comm, (void*)0);
    pthread_join(thread,NULL);
    //pthread_join(thread1,NULL);


    //while(flag==0){continue;}
    if(winner==0) return 0;

    printf("I am winner\n");
    
    char buff[100];
    recv(sfd,buff,sizeof(buff),0);
    printf("%s\n",buff);

}