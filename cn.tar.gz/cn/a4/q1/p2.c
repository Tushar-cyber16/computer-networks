
#include <stdio.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <unistd.h>
#include <stdlib.h>
#include <signal.h>
#define MAX 10

struct mesg_buffer {
	long msg_type;
	char msg_text[100];
} message;

int p1pid=0;
void hdfn(int sig, siginfo_t *info, void *context){
	//printf("PID of signal sender = %d\n", info->si_pid);
	p1pid=info->si_pid;
}

int flag=0;
void p1_p2()
{
	printf("SIGNAL FROM P1 TO P2\n");
	flag=1;
}

void p3_p2()
{
	printf("SIGNAL FROM P3 TO P2\n");
	flag=1;
}
int main()
{
	key_t key;
	int msgid;
    int left,right;

	key = ftok("progfile", 65);


	msgid = msgget(key, 0666 | IPC_CREAT);
	message.msg_type = 2;

     pid_t pid;
    pid = getpid();
    sprintf(message.msg_text,"%d\n",pid);

	msgsnd(msgid, &message, sizeof(message), 0);

	printf("Data send from p2 is : %s \n", message.msg_text);

   while(1) {
	   //signal(SIGUSR1,hdfn);
	   struct sigaction s;
	s.sa_flags = SA_SIGINFO;
	s.sa_sigaction= hdfn;
	sigaction(SIGUSR1, &s, NULL);
	pause();
	   
	   if(p1pid!=0)break;
	   }
	printf("signal received from p1 to p2 is %d\n",p1pid);
    left=p1pid;



	key = ftok("progfile", 65);

	msgid = msgget(key, 0666 | IPC_CREAT);

	msgrcv(msgid, &message, sizeof(message), 3, 0);

     int p3pid = atoi(message.msg_text);
     printf("Data Received from p3 to p2 is  : %d \n",p3pid);
	 right=p3pid;

	msgctl(msgid, IPC_RMID, NULL);




     key = ftok("progfile", 65);


	msgid = msgget(key, 0666 | IPC_CREAT);
	message.msg_type = 1;

    pid_t pidd;
	pidd =left;
	//printf("%d\n",left);
    sprintf(message.msg_text,"%d\n",pidd);
    message.msg_type=1;
	msgsnd(msgid, &message, sizeof(message), 0);

	printf("Data send from p2 i.e pid1 is : %s \n", message.msg_text);


	printf("signal send from p2 to p3 %d\n",getpid());
    kill(p3pid,SIGUSR1);



for(int i=0;i<3;i++)
	{
		while(1)
		{
            signal(SIGUSR1,p1_p2);
			if(flag){flag=0;break;}
		}
		kill(right,SIGUSR1);
	}

    for(int i=0;i<3;i++)
	{
		while(1)
		{
            signal(SIGUSR1,p3_p2);
			if(flag){flag=0;break;}
		}
		kill(left,SIGUSR1);
	}

	return 0;
}
