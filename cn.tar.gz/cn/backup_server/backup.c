#include<time.h>
#include<stdio.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<string.h>
#include<sys/select.h>
#include<pthread.h>
#include<signal.h>
#include<stdlib.h>
#include<fcntl.h>
#include<sys/shm.h>
#include<unistd.h>
#include<sys/un.h>
#include<netinet/ip.h>
#include<arpa/inet.h>
#include <stddef.h>
#include<errno.h>
#include<netinet/if_ether.h>
#include <semaphore.h>
#include<net/ethernet.h>
#include<netinet/ether.h>
#include<netinet/udp.h>
#define SHM_KEY1 0x1234
int flag=0;

struct client {
    int nsfd;
};

struct backup{
    int client[30];
};


void* handle_client(void *args)
{
    struct client *arg = (struct client*) args;
    int nsfd = arg->nsfd;

    char buf[1000]="client are handled by backup server";
    printf("server : %s\n",buf);
    send(nsfd,buf,sizeof(buf),0);
    while(1)
    {
        printf("from client : ");

        recv(nsfd,buf,sizeof(buf),0);
        printf("%s\n",buf);
        if(strncmp("Bye",buf,3) == 0 ) break;
         if(flag==1) break;


        printf("server : ");

        fgets(buf,sizeof(buf),stdin);
        send(nsfd,buf,sizeof(buf),0);

    }
}

int main()
{
     sem_t* s;
     s= sem_open("/my_semaphore3", O_CREAT, 0666, 0); 
     sem_wait(s);
     int shmid = shmget(SHM_KEY1,1024,0666|IPC_CREAT);

     struct backup *c= (struct backup*) shmat(shmid,(void*)0,0);

     int sfd = c->client[0];
     int nsfd = c->client[1];
     printf("client0 %d, client1 %d\n",sfd,nsfd);
   printf("in backup\n");
     char buf[1000];
    while(1)
    {
        
        //sleep(4);
        recv(nsfd,buf,sizeof(buf),0);
        printf("from client : %s\n",buf);
        if(strncmp("Bye",buf,3) == 0 ) break;
         if(flag==1) break;


        printf("server : ");

        fgets(buf,sizeof(buf),stdin);
        send(nsfd,buf,sizeof(buf),0);

    }
     
     struct sockaddr_in inet_cliaddr ;
    int clen;
    if((nsfd=accept(sfd,(struct sockaddr*)&inet_cliaddr,&clen))<0)
    {
        perror("inet 1 accept");
        exit(1);
    }
    else printf("new client connected\n");
    
     memset(buf,'\0',sizeof(buf));
    while(1)
    {

        recv(nsfd,buf,sizeof(buf),0);
        printf("from client : %s\n",buf);
        if(strncmp("Bye",buf,3) == 0 ) break;
         if(flag==1) break;


        printf("server : ");

        fgets(buf,sizeof(buf),stdin);
        send(nsfd,buf,sizeof(buf),0);

    }

     /*pthread_t pthread[30];
     int j=0;
     for( int i=1;i<30;i++)
     {
         if(c->client[i] != 0)
         {
             
              struct client cli;
               cli.nsfd = c->client[i];
              pthread_create(&pthread[j++], NULL, (void*)handle_client, (void*)&cli);
         }
     }
     for(int i=1;i<j;i++)
     {
         pthread_join(pthread[i],NULL);
     }
     */

    /* while(1)
     {
         int nsfd ;
         struct sockaddr_in inet_cliaddr ;
         int clen;
             if((nsfd=accept(sfd,(struct sockaddr*)&inet_cliaddr,&clen))<0)
             {
                 perror("inet 1 accept");
                   exit(1);
            }
            else
            {
                     pthread_t thread1 ;
              struct client cli;
               cli.nsfd = nsfd;
               for(int i=0;i<30;i++) 
               {
                   if(c->client[i] ==0 ) {c->client[i] = nsfd;break;}
               }
              pthread_create(&thread1, NULL, (void*)handle_client, (void*)cli);
            }
     }
     */
}