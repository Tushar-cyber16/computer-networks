#include<stdio.h>


int main()
{
    int x,y;
    scanf("%d",&x);
    FILE* fp =fopen("in3.txt","w");
    //fprintf(fp,"%d",x);
    //printf("%d\n",x);
    y=x*2;
  fprintf(fp,"%d",y);
    printf("%d ",y);
    return 0;
}