#include<stdio.h>

int main(){
	printf("Sending data from P2\n");
  return 0;
}