#include<stdio.h>

int main()
{
	int n;
	scanf("%d",&n);
	for(int i=0;i<n;i++)
	{
		int x,y;
        scanf("%d",&x);
        scanf("%d",&y);
        printf("%d\n",x+y);
		printf("%d\n",x-y);
		printf("%d\n",x*y);
	}
	return 0;
} 