div.mw-geshi div,div.mw-geshi div pre,span.mw-geshi,pre.source-css,pre.source-javascript{font-family:monospace,Courier !important}  @media print{  }

/* cache key: wikidb:resourceloader:filter:minify-css:4:990d0644862009377a1a48a78b53b366 */
