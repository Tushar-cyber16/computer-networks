#include <stdio.h>
#include <poll.h>
#include<stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#define NUM_PROCESSES 4

int main() {

    printf("Hello\n");
    int i;
    struct pollfd fds[NUM_PROCESSES];
    FILE *fptrs[NUM_PROCESSES];
    char buf[512];

    // // Open pipes to P2, P3, P4, and P5
    fptrs[0] = popen("./P1", "r");
    fptrs[1] = popen("./P2", "r");
    fptrs[2] = popen("./P3", "r");
    fptrs[3] = popen("./P4", "r");

    // // Set up poll structures
    for (i = 0; i < NUM_PROCESSES; i++) {
        //printf("%d\n", fileno(fptrs[i]));
        fds[i].fd = fileno(fptrs[i]);
        fds[i].events=0;
        fds[i].events |= POLLIN;
        fds[i].revents=0;
    }

    // // Wait for data from any of P1, P2, P3, or P4
    
   int check=0;
    // // Check which process has data and feed it to P6
    for (i = 0; i < NUM_PROCESSES; i++) {
        int poll_result = poll(fds, NUM_PROCESSES, -1);
    if (poll_result == -1) {
        perror("poll");
        return 1;
    }
        if (fds[i].revents & POLLIN) {
            while (fgets(buf, sizeof(buf), fptrs[i])) {
                FILE *p6 = popen("./P5", "w");
                fputs(buf, p6);
                pclose(p6);
            }
            check=1;
           // break;
        }
    }
      for (i = 0; i < NUM_PROCESSES; i++) 
        pclose(fptrs[i]);

    // // If no data is available from any process, feed data from P6 to P5
    if (i == NUM_PROCESSES && check==0) {
        FILE *p1 = popen("./P6", "r");
        if (p1) {
            while (fgets(buf, sizeof(buf), p1)) {
                FILE *p6 = popen("./P5", "w");
                fputs(buf, p6);
                pclose(p6);
                 //system("./P5");
               // char c;
                //fgets(c, sizeof(c), stdin);
            }
            pclose(p1);
        }
    }

    // // Close pipes to P2, P3, P4, and P5
   
    
return 0;
}
