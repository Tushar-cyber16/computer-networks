#include <arpa/inet.h>
#include <stdio.h>
#include <string.h>
#include<stdlib.h>
#include <sys/socket.h>
#include <sys/types.h>
#include<netinet/in.h>
#include <unistd.h>
#include<netdb.h>
#include<stdbool.h>
#include <errno.h>
#include <sys/time.h> 
int main()
{
    struct sockaddr_in serv_addr[4];
    int addr_len[4] ;
    for(int i=0;i<4;i++) addr_len[i] =sizeof(serv_addr[i]);
    int sfd[4],opt[4] ;

    for(int i=0;i<4;i++)
    {opt[i]=true;
    if( ( ( sfd[i] = socket(AF_INET,SOCK_STREAM,0) ) )< 0)
    {
        fprintf(stderr,"socket connection failed");
        exit(EXIT_FAILURE);
    }
    
    if(setsockopt(sfd[i],SOL_SOCKET,SO_REUSEADDR | SO_REUSEPORT , (char*)&opt[i],sizeof(opt[i])) < 0 )
    {
		perror("setsockopt");
		exit(EXIT_FAILURE);
	}

    serv_addr[i].sin_family = AF_INET;
    serv_addr[i].sin_port = htons(8000+i);
    serv_addr[i].sin_addr.s_addr =INADDR_ANY;
    //bcopy((char*) server->h_addr , (char*) serv_addr.sin_addr.s_addr , server->h_length);

    if( bind(sfd[i],(struct sockaddr*) &serv_addr[i],sizeof(serv_addr[i])) < 0)
    {
        fprintf(stderr,"bind error");
       exit(EXIT_FAILURE);
    }
    
    if(listen(sfd[i],3) < 0)
    {
        fprintf(stderr, "listen failed");
        exit(EXIT_FAILURE);
    }
    }

while(1)
{
    fd_set rfds;
    FD_ZERO(&rfds);
    int mx=-1;
    for(int i=0;i<4;i++) 
    {
       if(sfd[i]!=-1) { FD_SET(sfd[i],&rfds);if(mx<sfd[i]) mx=sfd[i];}
    }
    int retval = select(mx+1,&rfds,NULL,NULL,NULL);

    if ((retval < 0) && (errno!=EINTR))
		{
			printf("select error");
		}

        for(int i=0;i<4;i++)
        {
            if(sfd[i]==-1)continue;
            if(FD_ISSET(sfd[i],&rfds))
            {
                int c=0;
                c=fork();
                if(c==0)
                {
                    dup2(sfd[i],3);
                    char data[] = {"./s3"};
                    data[3]=i+'1';
                    char *args[] = {data,NULL};
                    execvp(args[0],args);
                    exit(0);
                }
else {//wait(NULL);
                sfd[i]=-1;}
          
     

            }
        }
    
}


}