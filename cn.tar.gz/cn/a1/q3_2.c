#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <ctype.h>

int main()
{
    int fd_12[2],fd1[2],fd2[2];

    if(pipe(fd_12) == -1 || pipe(fd1) == -1 || pipe(fd2)==-1)
	{
		fprintf(stderr, "piping failed\n");
		return -1;
	}

    dup2(STDIN_FILENO,fd_12[0]);
    dup2(STDOUT_FILENO,fd_12[1]);

    dup2(3,STDIN_FILENO);
    dup2(4,STDOUT_FILENO);

    int c=0;
    c=fork();

    if(c==0)
    {
        printf("I am process P2 ------ ");
            dup2(STDIN_FILENO,3);
            dup2(STDOUT_FILENO,4);
            dup2(fd1[0],STDIN_FILENO);
            dup2(fd2[1],STDOUT_FILENO);
          
            char* args[] ={"./q3_3",NULL};
            execvp(args[0],args);
            exit(0);
    }
    else
    {
        //wait(NULL);
       while(1)
       {
           char buffer[100];
          printf("Process 2\n");
           read(fd_12[0],buffer,100);
           write(fd1[1],buffer,strlen(buffer)+1);
           
           char data[100];
                     printf("Process 2\n");
           read(fd2[0],data,100);
           write(fd_12[1],data,strlen(data)+1);

       }
    }
}