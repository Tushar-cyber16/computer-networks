#include<bits/stdc++.h>
using namespace std;
bool parity(int p,int k,int arr[])
{
  int count = 0 ,x = (1 << k);
  int igr = pow(2,k);
  //cout<<x<<endl;
  for(int i=1;i<=p;i++)
  {
  if(i == igr) continue;
  if( (x&i) > 0) 
  {
  cout<<i<<" "<<arr[i]<<endl;
  if(arr[i] == 1)count++;
  }
  }
  cout<<endl;
  //cout<<igr<<" "<<count<<endl;
  if(count%2==0)return false;
  else return true;
  
  
}
int main()
{

     string s;
     cout<<"enter the message : ";
     cin>>s;
     
     int x =s.length();
     
     int p = log2(x)+1;
     //cout<<p<<endl;
     int y = log2(x+p);
     y++;
     if(y > p) p++;
     //cout<<p<<endl;
     p+=x;
      int arr[p+1],check = 1,j=0;
      for(int i=1;i<=p;i++)
      {
        if(i==check)
        {
        check*=2;
        continue;
        }
        
        arr[i] = s[j++]-'0';
      }
      
      check=1;
      int k=0;
      while(check <=p)
      {
        bool flag = parity(p,k,arr);
        if(flag) arr[check] =1;
        else arr[check]=0;
        k++;
        check*=2;
      }
      for(int i=1;i<=p;i++)cout<<arr[i]<<" ";
      cout<<endl;
      
      int pos;
      cout<<"enter position of bit to change : ";
      cin>>pos;
      
      if(arr[pos] == 0) arr[pos] =1;
      else arr[pos] = 0;
      cout<<"new changes message : ";
      for(int i=1;i<=p;i++)cout<<arr[i]<<" ";
      cout<<endl;
      
      int par = log2(p)+1;
      int index=0;
      for(int i=0;i<par;i++)
      {
       int ind = pow(2,i);
       
       bool flag = parity(p,i,arr);
       if(flag)
       {
         if(arr[ind] != 1) {cout<<i<<endl;index+=pow(2,i);}
       } 
       else
       {
        if(arr[ind] !=0 ) {cout<<i<<endl;index+=pow(2,i);}
       }
      }
       
       cout<<"position changes is : ";
       cout<<index<<endl;
       


}
