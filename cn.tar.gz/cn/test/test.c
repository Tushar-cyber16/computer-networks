#include <arpa/inet.h>
#include <errno.h>
#include <netinet/in.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <strings.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <semaphore.h>

#include <fcntl.h>
#include <sys/stat.h>
int main()
{

int fd = fileno(popen("pidof ./hello", "r"));	
char s[1000];
	read(fd, &s, 1000);
	int X = atoi(s);
  printf("%d\n",X);
}
