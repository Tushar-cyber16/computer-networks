#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <ctype.h>

int main()
{
    int fd1[2],fd2[2];

    if(pipe(fd1) == -1 || pipe(fd2)==-1)
    {
        fprintf(stderr,"piping failed");
        return -1;
    }

    int c=0;
    c=fork();

    if(c==0)
    {
        dup2(STDIN_FILENO,3);
        dup2(STDOUT_FILENO,4);

        dup2(fd1[0],STDIN_FILENO);
        dup2(fd2[1],STDOUT_FILENO);

        char* args[] = {"./q3_2",NULL};
        execvp(args[0],args);
        exit(0);
    }
    else
    {
        //wait(NULL);
        while(1)
        {
        char buffer[100];
        printf("process 1\n");
        fgets(buffer,100,stdin);
        write(fd1[1],buffer,strlen(buffer)+1);
        
        char data[100];
        read(fd2[0],data,100);
        //printf("I am process P1 ------ ");
        printf("I am process P1 ------  %s\n",data);
        }
    }
}