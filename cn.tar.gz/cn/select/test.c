#include <stdio.h>
#include <sys/time.h>
#include <sys/types.h>
#include <unistd.h>

int main()
{
    
        printf("message from pipe test.c");
    
    return 0;
}