#include<time.h>
#include<stdio.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<string.h>
#include<sys/select.h>
#include<pthread.h>
#include<signal.h>
#include<stdlib.h>
#include<fcntl.h>
#include<sys/shm.h>
#include<unistd.h>
#include<sys/un.h>
#include<netinet/ip.h>
#include<arpa/inet.h>
#include<errno.h>
#include<netinet/if_ether.h>
#include<net/ethernet.h>
#include<netinet/ether.h>
#include<netinet/udp.h>
#include<sys/ipc.h>
#include<sys/msg.h>
#include <semaphore.h>
#define socketPath "mysocket"
int usfd;
sem_t *s2;
int recv_fd(int socket)
 {
  int sent_fd, available_ancillary_element_buffer_space;
  struct msghdr socket_message;
  struct iovec io_vector[1];
  struct cmsghdr *control_message = NULL;
  char message_buffer[1];
  char ancillary_element_buffer[CMSG_SPACE(sizeof(int))];

  /* start clean */
  memset(&socket_message, 0, sizeof(struct msghdr));
  memset(ancillary_element_buffer, 0, CMSG_SPACE(sizeof(int)));

  /* setup a place to fill in message contents */
  io_vector[0].iov_base = message_buffer;
  io_vector[0].iov_len = 1;
  socket_message.msg_iov = io_vector;
  socket_message.msg_iovlen = 1;

  /* provide space for the ancillary data */
  socket_message.msg_control = ancillary_element_buffer;
  socket_message.msg_controllen = CMSG_SPACE(sizeof(int));

  if(recvmsg(socket, &socket_message, MSG_CMSG_CLOEXEC) < 0)
   return -1;

  if(message_buffer[0] != 'F')
  {
   /* this did not originate from the above function */
   return -1;
  }

  if((socket_message.msg_flags & MSG_CTRUNC) == MSG_CTRUNC)
  {
   /* we did not provide enough space for the ancillary element array */
   return -1;
  }

  /* iterate ancillary elements */
   for(control_message = CMSG_FIRSTHDR(&socket_message);
       control_message != NULL;
       control_message = CMSG_NXTHDR(&socket_message, control_message))
  {
   if( (control_message->cmsg_level == SOL_SOCKET) &&
       (control_message->cmsg_type == SCM_RIGHTS) )
   {
    sent_fd = *((int *) CMSG_DATA(control_message));
    return sent_fd;
   }
  }

  return -1;
 }

  void* u_msg(void *args)
 {
        
        char buf[1000];
        fd_set rfds;
        FD_ZERO(&rfds);
        FD_SET(usfd,&rfds);
        while(1)
        {
            int retval = select(usfd+1,&rfds,NULL,NULL,NULL);
            
             if (retval == -1) 
         {
            perror("select");
            exit(EXIT_FAILURE);
        } 
        else if (retval == 0) 
        {
            // Timeout occurred
            printf("Timeout occurred\n");
        } 
        else 
        {
            if(FD_ISSET(usfd,&rfds))
            {
            recv(usfd,buf,sizeof(buf),0);
            printf("%s\n",buf);
            }
        }
        }
        //exit(1);
 }

 void* recvfd(void *args)
 {
     int recvfd;
   while(1)
      {
          if((recvfd = recv_fd(usfd)) == -1)
          {
               perror("recv fd failed");
                   exit(0);
          }
          printf("train arrived\n");
          char buf[1000];
          while(1)
          {
              recv(recvfd,buf,sizeof(buf),0);
              printf("%s\n",buf);

              if(strncmp("Leaving",buf,3) == 0) 
		       { 
                   sem_post(s2);
                    break;
		        }
          }
      }
     // exit(1);
 }

int main()
{
       s2 = sem_open("/my_semaphore2", O_CREAT, 0666, 0);
       usfd = socket(AF_UNIX,SOCK_STREAM,0);

    struct sockaddr_un addr;
    addr.sun_family = AF_UNIX;
    strcpy(addr.sun_path,socketPath);

 
    if(connect(usfd,(struct sockaddr *)&addr,sizeof(addr))==-1)
	perror("\n connect ");
   
   
    
    
    pthread_t thread,thread1;
      //pthread_create(&thread, NULL, (void*)u_msg, (void*)0);
      pthread_create(&thread1, NULL, (void*)recvfd, (void*)0);
    // pthread_join(thread,NULL);
      pthread_join(thread1,NULL);

    
    
    return 0;


}